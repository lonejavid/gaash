from django.apps import AppConfig


class GaashConfig(AppConfig):
    name = 'gaash'
